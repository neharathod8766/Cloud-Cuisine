import RestaurantList from "./restaurantList/restaurantList"

const AdminHome=()=>{
    return(
        <div className="contaimer-fluid">
             <RestaurantList/>
        </div>
       )
}
export default AdminHome