package com.app.entities;

public enum Status {
	ACTIVE, INACTIVE
}
