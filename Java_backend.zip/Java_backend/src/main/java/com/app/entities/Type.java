package com.app.entities;

public enum Type {
	VEG,NONVEG
}
