import RestoNav from './../../components/RestoNav';
import AllOrders from './../../Pages/Restaurant/allOrders';
const RestaurantHome=()=>{
    return(
        <div className="container-fluid">
        <AllOrders />
        </div>
    )
}

export default RestaurantHome