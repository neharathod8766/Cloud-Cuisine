const config = {
  serverURL: "http://localhost:8080/CloudCuisine"
};

export default config;
